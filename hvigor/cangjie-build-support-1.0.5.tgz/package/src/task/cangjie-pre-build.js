"use strict";
var __createBinding = this && this.__createBinding || (Object.create ? function (e, t, i, o) {
    void 0 === o && (o = i);
    var r = Object.getOwnPropertyDescriptor(t, i);
    r && !("get" in r ? !t.__esModule : r.writable || r.configurable) || (r = {
        enumerable: !0, get: function () {
            return t[i]
        }
    }), Object.defineProperty(e, o, r)
} : function (e, t, i, o) {
    void 0 === o && (o = i), e[o] = t[i]
}), __setModuleDefault = this && this.__setModuleDefault || (Object.create ? function (e, t) {
    Object.defineProperty(e, "default", { enumerable: !0, value: t })
} : function (e, t) {
    e.default = t
}), __importStar = this && this.__importStar || function (e) {
    if (e && e.__esModule) {
        return e;
    }
    var t = {};
    if (null != e) {
        for (var i in e) {
            "default" !== i && Object.prototype.hasOwnProperty.call(e, i) &&
            __createBinding(t, e, i);
        }
    }
    return __setModuleDefault(t, e), t
}, __importDefault = this && this.__importDefault || function (e) {
    return e && e.__esModule ? e : { default: e }
};
Object.defineProperty(exports, "__esModule", { value: !0 }), exports.CangjiePreBuild = void 0;
const hvigor_1 = require("@ohos/hvigor"), fs_1 = __importDefault(require("fs")), os_1 = __importDefault(require("os")),
    path = __importStar(require("path")), common_util_1 = require("@ohos/hvigor-ohos-plugin/src/common/common-util"),
    module_ohos_config_manager_1 = require("@ohos/hvigor-ohos-plugin/src/common/global/module-ohos-config-manager"),
    project_ohos_config_manager_1 = require("@ohos/hvigor-ohos-plugin/src/common/global/project-ohos-config-manager"),
    build_directory_const_1 = require("@ohos/hvigor-ohos-plugin/src/const/build-directory-const"),
    common_const_1 = require("@ohos/hvigor-ohos-plugin/src/const/common-const"),
    inject_const_1 = require("@ohos/hvigor-ohos-plugin/src/const/inject-const"),
    sdk_const_1 = require("@ohos/hvigor-ohos-plugin/src/const/sdk-const"),
    module_type_enum_1 = require("@ohos/hvigor-ohos-plugin/src/enum/module-type-enum"),
    runtime_type_enum_1 = require("@ohos/hvigor-ohos-plugin/src/enum/runtime-type-enum"),
    error_code_map_1 = require("@ohos/hvigor-ohos-plugin/src/error/error-code-map"),
    hap_extra_info_1 = require("@ohos/hvigor-ohos-plugin/src/project/data/hap-extra-info"),
    dependency_interface_1 = require("@ohos/hvigor-ohos-plugin/src/project/dependency/core/dependency-interface"),
    dependency_manager_1 = require("@ohos/hvigor-ohos-plugin/src/project/dependency/dependency-manager"),
    project_extra_info_service_1 = require("@ohos/hvigor-ohos-plugin/src/project/project-extra-info-service"),
    array_util_1 = require("@ohos/hvigor-ohos-plugin/src/utils/array-util"),
    file_util_1 = require("@ohos/hvigor-ohos-plugin/src/utils/file-util"),
    res_model_loader_1 = require("@ohos/hvigor-ohos-plugin/src/utils/loader/file/res-model-loader"),
    ohos_logger_1 = require("@ohos/hvigor-ohos-plugin/src/utils/log/ohos-logger"),
    task_util_1 = require("@ohos/hvigor-ohos-plugin/src/utils/task-util"),
    error_handlers_1 = require("@ohos/hvigor-ohos-plugin/src/utils/validate/error-handlers"),
    validate_config_1 = require("@ohos/hvigor-ohos-plugin/src/utils/validate/validate-config"),
    validate_util_1 = require("@ohos/hvigor-ohos-plugin/src/utils/validate/validate-util"),
    abstract_pre_build_1 = require("@ohos/hvigor-ohos-plugin/src/tasks/abstract/abstract-pre-build"),
    target_task_service_1 = require("@ohos/hvigor-ohos-plugin/src/tasks/service/target-task-service"),
    json_util_1 = require("@ohos/hvigor-ohos-plugin/src/utils/json-util"),
    const_1 = require("@ohos/hvigor/src/common/const/const"),
    path_const_1 = require("@ohos/hvigor/src/common/const/path-const"),
    cangjie_task_names_1 = require("./cangjie-task-names"),
    ohos_test_util_1 = require("@ohos/hvigor-ohos-plugin/src/utils/ohos-test-util"),
    constants_1 = require("../constants/constants"),
    log_adaptor_1 = require("@ohos/hvigor-ohos-plugin/src/utils/log/log-adaptor"),
    mock_config_utils_1 = require("@ohos/hvigor-ohos-plugin/src/utils/mock-config-utils"),
    build_profile_utils_1 = require("@ohos/hvigor-ohos-plugin/src/utils/build-profile-utils"),
    byte_code_har_utils_1 = require("@ohos/hvigor-ohos-plugin/src/utils/byte-code-har-utils"),
    build_option_path_info_1 = require("@ohos/hvigor-ohos-plugin/src/common/build-option-path-info"),
    cangjie_file_util_1 = require("../utils/cangjie-file-util"),
    module_option_path_info_1 = require("@ohos/hvigor-ohos-plugin/src/common/module-option-path-info"),
    inject_util_1 = require("@ohos/hvigor-ohos-plugin/src/utils/inject-util"),
    _log = ohos_logger_1.OhosLogger.getLogger("cangjie-preBuild");

class CangjiePreBuild extends abstract_pre_build_1.AbstractPreBuild {
    constructor(e) {
        super(e, cangjie_task_names_1.CangjieTaskNames.CANGJIE_PRE_BUILD), this.INSIGHT_INTENT_SRC_ENTRY =
            "insightIntent-srcEntry", this.MODULE_SRC_ENTRY = "module-srcEntry", this.MODULE_ABILITIES_SRC_ENTRY =
            "module-abilities-srcEntry", this.MODULE_EXTENSION_ABILITIES_SRC_ENTRY =
            "module-extensionAbilities-srcEntry";
        const t = this.projectModel.getAppRes();
        this.appJson5Path = t.getJsonPath();
        const i = e.getTargetData().getModuleSourceSetModel().getModuleTargetRes();
        this.targetJsonPath = i.getJsonPath(), this.targetModuleOptObj = i.getModuleJsonOpt(), this.formJsonPathArr =
            target_task_service_1.TargetTaskService.getFormJsonArr(i), this.resourcePath =
            i.getResourcePath(), this.appStartupPath = e.getAppStartupPath(), this.routerMapJsonPath =
            e.getRouterMapJsonPath(this.moduleModel), this.insightIntentJsonPath =
            path.resolve(e.getTargetData().getPathInfo().getModuleSrcMainResourceBaseProfilePath(),
                build_directory_const_1.BuildArtifactConst.INSIGHT_INTENT_JSON), this.pagesJsonPath =
            this.getPagesJsonPath(), this.arkDataPath =
            path.resolve(e.getTargetData().getPathInfo().getModuleSrcMainResourceRawfileArkdataPath()), this.utdPath =
            path.resolve(e.getTargetData().getPathInfo()
                .getModuleSrcMainResourceRawfileUtdPath()), this.hvigorConfigPath =
            path.resolve(path_const_1.HVIGOR_PROJECT_WRAPPER_HOME,
                const_1.DEFAULT_HVIGOR_CONFIG_JSON_FILE_NAME), this.isPreview =
            hvigor_1.hvigorCore.getExtraConfig().get(inject_const_1.InjectConst.BUILD_ROOT) ===
            build_directory_const_1.BuildDirConst.PREVIEW_BUILD_PATH, this.extendSourceValidateResult =
            this.getExtendSourceDirsValidateResult(), this.mockCacheClean()
    }

    declareInputs() {
        var e, t;
        const i = super.declareInputs(), o = Object.keys(this.getDependencies(this.moduleModel, !1)),
            r = Object.keys(this.getDependencies(this.projectModel, !1)), s =
                (0, build_profile_utils_1.getRuntimeOnlyObjMap)(this.module.getNodeDir(), null ===
                    (t = null === (e = this.targetService.getBuildOption()) || void 0 === e ? void 0 : e.arkOptions) ||
                    void 0 === t ? void 0 : t.runtimeOnly, (0, array_util_1.getUnionSet)(o, r));
        for (const [e, t] of s) {
            i.set(e, t);
        }
        const a = project_ohos_config_manager_1.projectOhosConfigManager.getConfig();
        a && i.set("appHvigorFileConfig", (0, hvigor_1.hash)(JSON.stringify(a)));
        const n = module_ohos_config_manager_1.moduleOhosConfigManager.getConfig(this.moduleName);
        return n &&
        i.set("moduleHvigorFileConfig", (0, hvigor_1.hash)(JSON.stringify(n))), this.formJsonPathArr.forEach((e => {
            const t = (0, hvigor_1.parseJsonFile)(e, !1);
            t.forms && t.forms.forEach((e => {
                if (!e.src) {
                    return;
                }
                const t = "arkts" === e.uiSyntax ? path.resolve(this.moduleModel.getProjectDir(), "src/main", e.src) :
                path.resolve(this.moduleModel.getProjectDir(), "src/main", `${e.src}.json`);
                fs_1.default.existsSync(t) && i.set(e.src, t)
            }))
        })), this.getDeclareInputs(i), i
    }

    declareInputFiles() {
        const e = (new hvigor_1.FileSet).addEntries([this.appJson5Path, this.targetJsonPath, ...this.formJsonPathArr],
            { isDirectory: !1 });
        fs_1.default.existsSync(this.projectProfilePath) &&
        e.addEntry(this.projectProfilePath), fs_1.default.existsSync(this.profilePath) &&
        e.addEntry(this.profilePath), this.appStartupPath && fs_1.default.existsSync(this.appStartupPath) &&
        e.addEntry(this.appStartupPath);
        const t = this.routerMapJsonPath;
        t && fs_1.default.existsSync(t) && e.addEntry(t), this.targetService.getWorkerConfig().forEach((t => {
            fs_1.default.existsSync(t) && e.addEntry(t)
        })), fs_1.default.existsSync(this.syscapJsonPath) && e.addEntry(this.syscapJsonPath), void 0 !==
        this.pagesJsonPath && e.addEntry(this.pagesJsonPath), fs_1.default.existsSync(this.insightIntentJsonPath) &&
        e.addEntry(this.insightIntentJsonPath), fs_1.default.existsSync(this.arkDataPath) &&
        e.addEntry(this.arkDataPath, { isDirectory: !0 }), fs_1.default.existsSync(this.utdPath) &&
        e.addEntry(this.utdPath, { isDirectory: !0 }), fs_1.default.existsSync(this.hvigorConfigPath) &&
        e.addEntry(this.hvigorConfigPath,
            { isDirectory: !0 }), fs_1.default.existsSync(this.moduleModel.getMockConfigPath()) &&
        e.addEntry(this.moduleModel.getMockConfigPath(), { isDirectory: !1 });
        const i = this.isOhpmProject ? this.moduleModel.getOhPackageJson5Path() : this.moduleModel.getPackageJsonPath();
        return fs_1.default.existsSync(i) && e.addEntry(i), e
    }

    async beforeAlwaysAction() {
        await super.beforeAlwaysAction(), this.checkEntryModuleJson(), this.checkIntegratedHspHsp(), this.checkTransformLib()
    }

    validateAtomicService() {
        var e, t, i, o;
        if (!this.isAtomicServiceProject()) {
            return void _log.debug("current product is not Atomic service.");
        }
        const r = this.getBundleType(), s =
            null === (t = null === (e = this.targetModuleOptObj) || void 0 === e ? void 0 : e.module) || void 0 === t ?
                void 0 : t.installationFree, a = this.targetService.getBuildOption().externalNativeOptions,
            n = this.getAtomicServiceErrorPath(r, s),
            l = "Atomic service development is not supported in the OpenHarmony stage model.";
        this.targetData.isHarmonyOS() || (this.validateSpecificField(r, s, l), _log._buildError(l)._detail(n)
            ._printErrorAndExit()), (0, task_util_1.limitMinApiVersion)(this.targetData,
            sdk_const_1.ApiVersion.API_VERSION_10) ||
        _log._buildError("Atomic service development is not supported compileSdkVersion/compatibleSdkVersion less than api 11.")
            ._printErrorAndExit(), a &&
        _log._buildError("Atomic service development is not supported Native development.")._printErrorAndExit();
        const d = this.service.getModuleModel().getModuleType();
        d !== module_type_enum_1.ModuleType.Har && d !== module_type_enum_1.ModuleType.Shared &&
            (this.formJsonPathArr.forEach((e => {
                const t = (0, hvigor_1.parseJsonFile)(e, !1);
                if (t.forms) {
                    for (const e of t.forms) {
                        e.uiSyntax && "arkts" === e.uiSyntax ||
                        _log._buildError("Atomic service development is only supported arkts widget.")
                            ._printErrorAndExit()
                    }
                }
            })), void 0 !==
                (null === (o = null === (i = this.targetModuleOptObj) || void 0 === i ? void 0 : i.module) ||
                    void 0 === o ? void 0 : o.mainElement) ||
                this.targetName === common_const_1.DefaultTargetConst.OHOS_TEST_TARGET &&
                (0, ohos_test_util_1.isTemplatesAfterSourceCodeMigration)(this.moduleModel.getSourceRootByTargetName(common_const_1.DefaultTargetConst.OHOS_TEST_TARGET)) ||
            _log._buildError("If the entry or feature module is atomicService, the mainElement tag in the module.json5 must be configured.")
                ._detail(this.targetJsonPath)._printErrorAndExit())
    }

    doValidateForDiffApiType() {
        var e;
        if (this.appJson5Validate(), this.moduleJson5Validate(), this.formJsonValidate(), this.pagesJsonValidate(), this.routerMapJsonValidate(), this.hvigorFileConfigValidate(), this.appStartupValidate(), this.sysCapValidate(), this.hvigorConfigValidate(), this.validateMockConfig(), this.checkAppConfiguration(), fs_1.default.existsSync(this.insightIntentJsonPath) &&
            (this.buildProfileJsonValidate(), this.insightIntentJsonValidate()), this.targetESVerisonValidate(), fs_1.default.existsSync(this.utdPath)) {
            const e = fs_1.default.readdirSync(this.utdPath);
            if (void 0 !== e && e.length > 0) {
                for (const t of e) {
                    const e = path.resolve(this.utdPath, t);
                    this.utdJsonValidate(e)
                }
            }
        }
        if (fs_1.default.existsSync(this.arkDataPath)) {
            const e = fs_1.default.readdirSync(this.arkDataPath);
            if (void 0 !== e && e.length > 0) {
                for (const t of e) {
                    const e = path.resolve(this.arkDataPath, t);
                    this.arkDataJsonValidate(e)
                }
            }
        }
        (null === (e = this.service.getModuleModel()) || void 0 === e ? void 0 : e.isHapModule()) &&
        this.validateMainElement(), this.checkOHMURL(), this.checkDynamicImportFile(), this.checkAppStartupConfig(), this.checkAllSrcEntry(), this.checkBundledDependencies()
    }

    mockCacheClean() {
        const e = this.moduleModel.getMockConfigPath();
        if (!fs_1.default.existsSync(e) && this.isPreview) {
            const e = this.targetData.getTargetName(), t = this.targetData.getPathInfo(), i = t.getModulePreviewPath(),
                o = t.getModulePreviewIntermediatesResPath(), r = path.resolve(i, `cache/.${e}/mock-config.json`);
            fs_1.default.existsSync(r) && fs_1.default.unlinkSync(r);
            const s = path.resolve(i, `cache/.${e}/mock-config.json5`);
            fs_1.default.existsSync(s) && fs_1.default.unlinkSync(s);
            const a = path.resolve(o, "mock-config.json");
            fs_1.default.existsSync(a) && fs_1.default.unlinkSync(a)
        }
    }

    targetESVerisonValidate() {
        var e, t, i;
        (null === (i =
            null === (t = null === (e = this.targetService.getBuildOption()) || void 0 === e ? void 0 : e.arkOptions) ||
                void 0 === t ? void 0 : t.tscConfig) || void 0 === i ? void 0 : i.targetESVersion) &&
            (this.compileApiVersion < sdk_const_1.ApiVersion.API_VERSION_12 ||
                this.compatibleApiVersion < sdk_const_1.ApiVersion.API_VERSION_12) &&
        _log._buildError("targetESVersion not supported when below API version 12. ")
            ._detail("Please check compileSdkVersion and compatibleSdkVersion in the project-level build-profile.json5 file.")
            ._printErrorAndExit()
    }

    checkByteCodeHar() {
        var e, t, i, o;
        if (!this.moduleModel.isHarModule()) {
            return;
        }
        const r =
            null === (t = null === (e = this.targetService.getBuildOption()) || void 0 === e ? void 0 : e.strictMode) ||
                void 0 === t ? void 0 : t.useNormalizedOHMUrl;
        // this.targetService.getByteCodeHar(r,
        //     null === (o = null === (i = this.targetService.getBuildOption()) || void 0 === i ? void 0 : i.arkOptions) ||
        //         void 0 === o ? void 0 : o.byteCodeHar) && (0, byte_code_har_utils_1.checkByteCodeHar)({
        //     logger: _log,
        //     useNormalizedOHMUrl: r,
        //     compileApiVersion: this.compileApiVersion,
        //     compatibleApiVersion: this.compatibleApiVersion
        // })
    }

    buildProfileJsonValidate() {
        project_extra_info_service_1.ProjectExtraInfoService.getProjectRuntimeOS(this.projectModel) !==
        runtime_type_enum_1.RuntimeTypeEnum.HARMONY_OS &&
        _log._buildError("The runtimeOS that supports the Insightintent project can only be HarmonyOS")
            ._detail(`Please check if the runtimeOS type of the project is HarmonyOS with '${this.projectProfilePath}'`)
            ._printErrorAndExit(), (this.compileApiVersion < sdk_const_1.ApiVersion.API_VERSION_11 ||
            this.compatibleApiVersion < sdk_const_1.ApiVersion.API_VERSION_11) &&
        _log._buildError("Invalid compileSdkVersion or compatibleSdkVersion value. ")
            ._detail("Insight intent not supported when below API version 11. Set compileSdkVersion and compatibleSdkVersion  to 4.1.0(11) or a larger value in the project-level build-profile.json5 file.")
            ._printErrorAndExit()
    }

    insightIntentJsonValidate() {
        const e = this.sdkInfo.getInsightIntentSchema();
        fs_1.default.existsSync(e) || _log._buildError("The current SDK version does not support InsightIntent.")
            ._detail("Open SDK Manager and update the SDK > HarmonyOS version to API version 11. ")
            ._printErrorAndExit(), validate_util_1.ValidateUtil.submitSchemaCheckWork({
            moduleName: this.projectModel.getName(),
            filePath: this.insightIntentJsonPath,
            schemaPath: e
        })
    }

    utdJsonValidate(e) {
        const t = this.sdkInfo.getUtdSchema();
        fs_1.default.existsSync(t) || _log._buildError("The current SDK version does not support ArkData.")
            ._detail("To use this feature, go to Tools > SDK Manager and update the SDK.")
            ._printErrorAndExit(), validate_util_1.ValidateUtil.submitSchemaCheckWork({
            moduleName: this.projectModel.getName(),
            filePath: e,
            schemaPath: t
        })
    }

    arkDataJsonValidate(e) {
        const t = this.sdkInfo.getArkDataSchema();
        fs_1.default.existsSync(t) || _log._buildError("The current SDK version does not support ArkData.")
            ._detail("To use this feature, go to Tools > SDK Manager and update the SDK.")
            ._printErrorAndExit(), validate_util_1.ValidateUtil.submitSchemaCheckWork({
            moduleName: this.projectModel.getName(),
            filePath: e,
            schemaPath: t
        })
    }

    appJson5Validate() {
        const e = this.targetService.getSdkInfo().getAppSchema(),
            t = this.moduleModel.getModuleType() === module_type_enum_1.ModuleType.Har;
        validate_util_1.ValidateUtil.submitSchemaCheckWork({
            moduleName: this.projectModel.getName(),
            filePath: this.appJson5Path,
            schemaPath: e,
            changeAppSchema: t
        })
    }

    moduleJson5Validate() {
        const e = this.targetName, t = this.targetService.getSdkInfo().getModuleSchema();
        validate_util_1.ValidateUtil.submitSchemaCheckWork({
            moduleName: this.moduleName,
            filePath: this.targetJsonPath,
            schemaPath: t,
            errorHandlers: [error_handlers_1.removeLegacyPhoneSupport, error_handlers_1.handleStartWindowErrors]
        }), e !== common_const_1.DefaultTargetConst.OHOS_TEST_TARGET &&
        this.validateModuleName(this.moduleName, this.targetModuleOptObj.module.name,
            common_const_1.CommonConst.MODULE_JSON5);
        const i = (0, hvigor_1.parseJsonFile)(this.targetJsonPath, !0),
            o = (0, hvigor_1.parseJsonFile)(this.targetJsonPath, !1);
        this.validateModuleSrcEntry(_log, (0, json_util_1.getJson5Obj)(this.targetJsonPath)), void 0 ===
        i.module.uiSyntax && this.sdkInfo.requireUISyntax() && _log._buildError("The SDK version is outdated.")
            ._solution("Open SDK Manager to update the ArkTS and JS components to the latest version.")
            ._file(this.targetJsonPath)
            ._printErrorAndExit(), validate_util_1.ValidateUtil.validateHybridDeviceTypes(i.module.deviceTypes), validate_util_1.ValidateUtil.validateDuplicatedName(o.module.abilities,
            "ability", this.targetJsonPath)
    }

    getJsonProfileByModel() {
        const e = res_model_loader_1.resModelLoader.getModuleJson(this.targetJsonPath);
        return {
            jsonFilePath: this.targetJsonPath,
            profile: e,
            deviceTypes: e.module.deviceTypes,
            deviceConfig: common_const_1.CommonConst.DEVICE_TYPES,
            configurationProfile: common_const_1.CommonConst.MODULE_JSON5
        }
    }

    checkExtendSourceDirs() {
        const { isValid:e, cause:t, detail:i } = this.extendSourceValidateResult;
        e || _log._buildError(t)._detail(i)._file(this.profilePath)._printErrorAndExit()
    }

    checkAppConfiguration() {
        const e = res_model_loader_1.resModelLoader.getAppJson(this.appJson5Path).app.configuration;
        if (!e) {
            return;
        }
        const t = this.getConfigurationFilePath(e);
        if (!t) {
            return;
        }
        const i = build_option_path_info_1.buildOptionPath.getAppConfigPath(this.appJson5Path, "configuration");
        fs_1.default.existsSync(t) || _log._buildError("Invalid configuration in the app.json5.")
            ._detail(`The path of '${e}' configuration file is not exist.`)._file(i)._printErrorAndExit();
        const o = this.sdkInfo.getAppConfigurationSchema();
        fs_1.default.existsSync(o) ||
        _log.errorMessageExit(`The schema file cannot be found:${o}\nCheck whether the file exists in the SDK.`), validate_util_1.ValidateUtil.submitSchemaCheckWork({
            moduleName: this.projectModel.getName(),
            filePath: t,
            schemaPath: o
        })
    }

    getConfigurationFilePath(e) {
        const t = (0, common_util_1.parsingProfileName)(e);
        if (!t) {
            return "";
        }
        const i = this.projectModel.getAppRes().getResourcePath();
        return path.resolve(i, "base/profile", `${t}.json`)
    }

    addConfigurationToInput(e) {
        var t, i;
        const o = null === (t = res_model_loader_1.resModelLoader.getAppJson(this.appJson5Path).app) || void 0 === t ?
            void 0 : t.configuration;
        if (e.set("configuration", null != o ? o : ""), o &&
        fs_1.default.existsSync(this.getConfigurationFilePath(o))) {
            const t = hvigor_1.Json5Reader.getJson5Obj(this.getConfigurationFilePath(o));
            e.set("configurationFileJson", null !== (i = JSON.stringify(t)) && void 0 !== i ? i : "")
        } else {
            e.set("configurationFileJson", "")
        }
    }

    formJsonValidate() {
        this.formJsonPathArr.forEach((e => {
            validate_util_1.ValidateUtil.submitSchemaCheckWork({
                moduleName: this.moduleName,
                filePath: e,
                schemaPath: this.sdkInfo.getFormSchema()
            }), this.validateFormSrc(e)
        }))
    }

    checkEntryModuleJson() {
        const e = (0, hvigor_1.parseJsonFile)(this.targetJsonPath, !0);
        if (e.module.uiSyntax) {
            const t = e.module.uiSyntax._line, i = e.module.uiSyntax._column + 1;
            _log._file(this.targetJsonPath)
                .warn(`uiSyntax has been deprecated.${os_1.default.EOL}         at ${this.targetJsonPath}:${t}:${i}`)
        }
    }

    getPagesJsonPath() {
        const e = (0, hvigor_1.parseJsonFile)(this.targetJsonPath, !1).module.pages,
            t = (0, common_util_1.parsingProfileName)(e);
        if (!t) {
            return;
        }
        const i = this.targetService.getResourceDirs().find((e => {
            const t = path.resolve(e, common_const_1.CommonConst.BASE_PROFILE);
            return t && fs_1.default.existsSync(t)
        })), o = path.resolve(this.moduleModel.getProjectDir(), null != i ? i : this.resourcePath,
            common_const_1.CommonConst.BASE_PROFILE, `${t}.json`);
        if (!fs_1.default.existsSync(o)) {
            const e = `Unable to find the '${t}.json' file or invalid resource directory configuration.`, i =
                `Check whether the default resource directory '.src/main/resources' exists, or if the resource directory customization is configured for current target ${this.targetName}, please check whether the resource directory of the current project is correctly configured.`;
            _log._buildError(e)._detail(i)._file(this.profilePath)._printErrorAndExit()
        }
        return o
    }

    pagesJsonValidate() {
        const e = this.getPagesJsonPath();
        void 0 !== e && validate_util_1.ValidateUtil.submitSchemaCheckWork({
            moduleName: this.moduleName,
            filePath: e,
            schemaPath: this.sdkInfo.getPageSchema()
        })
    }

    routerMapJsonValidate() {
        this.checkResReferenceConfig(common_const_1.CommonConst.ROUTER_MAP), this.routerMapJsonPath &&
        fs_1.default.existsSync(this.routerMapJsonPath) && validate_util_1.ValidateUtil.submitSchemaCheckWork({
            moduleName: this.moduleName,
            filePath: this.routerMapJsonPath,
            schemaPath: this.sdkInfo.getRouterMapSchema()
        })
    }

    appStartupValidate() {
        this.checkResReferenceConfig(common_const_1.CommonConst.APP_STARTUP), this.appStartupPath &&
        fs_1.default.existsSync(this.appStartupPath) && validate_util_1.ValidateUtil.submitSchemaCheckWork({
            moduleName: this.moduleName,
            filePath: this.appStartupPath,
            schemaPath: this.sdkInfo.getAppStartupSchema()
        })
    }

    sysCapValidate() {
        !this.targetData.isHarmonyOS() && fs_1.default.existsSync(this.syscapJsonPath) &&
        validate_util_1.ValidateUtil.submitSchemaCheckWork({
            moduleName: this.moduleName,
            filePath: this.syscapJsonPath,
            schemaPath: this.sdkInfo.getSysCapSchema()
        })
    }

    hvigorConfigValidate() {
        const e = common_const_1.BuildProfileSchemaFileConst.HVIGOR_CONFIG_SCHEMA_PATH;
        fs_1.default.existsSync(this.hvigorConfigPath) && fs_1.default.existsSync(e) &&
        validate_util_1.ValidateUtil.submitSchemaCheckWork({
            moduleName: this.projectModel.getName(),
            filePath: this.hvigorConfigPath,
            schemaPath: e
        })
    }

    validateFormSrc(e) {
        const t = (0, hvigor_1.parseJsonFile)(e, !1);
        if (void 0 !== t.forms) {
            for (const i of t.forms) {
                i.src ||
                _log._buildError("form src is required")._detail("Add form src field in the form config file.")._file(e)
                    ._printErrorAndExit();
                const t = this.moduleModel.getProjectDir(), o = path.resolve(t, "src/main"),
                    r = file_util_1.FileUtil.convertToAbsolutePath(i.src, o);
                path.normalize(r).startsWith(path.normalize(t)) ||
                _log._buildError(`${i.src} is not under ${t}`)._detail(`Modify ${i.src} in the form config file.`)
                    ._file(e)
                    ._printErrorAndExit();
                const s = "arkts" === i.uiSyntax;
                this.isValidWidget(s, o, r) ||
                _log._buildError(`Forms referenced in the config, '${i.src}', was not found in the project or the libraries.`)
                    ._detail(`Modify ${i.src} in the form config file.`)._file(e)._printErrorAndExit()
            }
        }
    }

    validateMainElement() {
        if (void 0 === this.targetModuleOptObj || this.isNewOhosTestTemplate()) {
            return;
        }
        const e = this.targetModuleOptObj.module.mainElement;
        if (this.targetModuleOptObj.module.installationFree && void 0 === e) {
            const e = "The 'mainElement' field not found in the module.json5 file.",
                t = "If the current project is of an atomic service, make sure the 'mainElement' field is included.";
            _log._buildError(e)._solution(t)._file(this.targetJsonPath)._printErrorAndExit()
        }
    }

    isNewOhosTestTemplate() {
        return this.targetName === common_const_1.DefaultTargetConst.OHOS_TEST_TARGET &&
        (0, ohos_test_util_1.isTemplatesAfterSourceCodeMigration)(this.moduleModel.getSourceRootByTargetName(common_const_1.DefaultTargetConst.OHOS_TEST_TARGET))
    }

    getAtomicServiceErrorPath(e, t) {
        let i = "";
        return void 0 !== e && "app" !== e || t && (i = this.targetJsonPath), e !==
        common_const_1.BundleType.ATOMIC_SERVICE && t || (i = this.appJson5Path), i
    }

    validateSpecificField(e, t, i) {
        e === common_const_1.BundleType.ATOMIC_SERVICE && t && _log._buildError(i)
            ._detail(`Please check installationFree in file: ${this.targetJsonPath} ${os_1.default.EOL}\t and bundleType in file: ${this.appJson5Path}`)
            ._printErrorAndExit()
    }

    validateMockConfig() {
        const e = (0, json_util_1.getJson5Obj)(this.moduleModel.getMockConfigPath());
        e && Object.values(e).forEach((e => {
            const t = e.source;
            if (t) {
                const e = path.resolve(this.moduleModel.getProjectDir(), t);
                fs_1.default.existsSync(e) ||
                _log._buildError(`source: ${t} not exists.`)._file(this.moduleModel.getMockConfigPath())
                    ._printErrorAndExit(this.moduleName)
            } else {
                _log._buildError("source key must exist")._file(this.moduleModel.getMockConfigPath())
                    ._printErrorAndExit(this.moduleName)
            }
        }))
    }

    checkDynamicImportFile() {
        var e, t;
        const i =
            null === (t = null === (e = this.targetService.getBuildOption()) || void 0 === e ? void 0 : e.arkOptions) ||
                void 0 === t ? void 0 : t.runtimeOnly;
        i && (this.checkApi(), this.doCheckDynamicImportFile(i), this.checkDependencies(i))
    }

    doCheckDynamicImportFile(e) {
        if (void 0 === e.sources) {
            return;
        }
        const t = this.targetService.isNoExternalImportByPath(), i = this.module.getNodeDir(), o = [], r = [], s = [],
            a = [], n = [], l =
                build_option_path_info_1.buildOptionPath.getTargetBuildOptPath(this.moduleModel, this.targetName,
                    "sources");
        this.projectModel.getAllModules().forEach((e => {
            n.push(e.getModule().getNodeDir())
        })), e.sources.forEach((e => {
            const t = path.resolve(i, e);
            n.some((e => t.startsWith(e))) || a.push(e), fs_1.default.existsSync(t) ?
                fs_1.default.statSync(t).isFile() &&
                    !common_const_1.ValidateRegExp.DYNAMIC_IMPORT_FILE_SUFFIX_REG_EXP.test(file_util_1.FileUtil.getFileSuffix(e)) &&
                s.push(e) : r.push(e), t.startsWith(this.module.getNodeDir()) || o.push(e)
        })), this.checkExistFilePath(r, l), this.checkOutsideModuleFile(a, l), this.checkSuffixFile(s,
            l), this.checkAcrossModule(o, t, l)
    }

    hvigorFileConfigValidate() {
        const e = project_ohos_config_manager_1.projectOhosConfigManager.getConfig();
        void 0 !== e &&
        (0, validate_config_1.validateOhosProjectConfig)(e, `${this.module.getProject().getBuildFilePath()}.ts`);
        const t = module_ohos_config_manager_1.moduleOhosConfigManager.getConfig(this.moduleName);
        void 0 !== t && (this.moduleModel.isHarModule() ?
        (0, validate_config_1.validateOhosHarModuleConfig)(t, `${this.module.getBuildFilePath()}.ts`) :
        (0, validate_config_1.validateOhosModuleConfig)(t, `${this.module.getBuildFilePath()}.ts`))
    }

    checkOHMURL() {
        var e, t;
        const i =
            null === (t = null === (e = this.targetService.getBuildOption()) || void 0 === e ? void 0 : e.strictMode) ||
                void 0 === t ? void 0 : t.useNormalizedOHMUrl;
        i && !(0, task_util_1.limitMinApiVersion)(this.targetData, sdk_const_1.ApiVersion.API_VERSION_11) &&
        _log.printErrorExit(new log_adaptor_1.OhosLogAdaptor("HE10301",
            hvigor_1.globalData.buildId).formatMessage(this.projectModel.getProfilePath()).getLogMessage());
        const o = this.targetService.getModuleService().getAllDependencies(), r = [];
        for (const e of o) {
            this.isEqualOHMUrl(e, i) || r.push(e.getPackageName());
        }
        r.length > 0 && _log.printErrorExit(new log_adaptor_1.OhosLogAdaptor("HE10300",
            hvigor_1.globalData.buildId).formatMessage(r.join(), String(i)).formatSolutions(0, r.join())
            .getLogMessage())
    }

    isEqualOHMUrl(e, t) {
        return e.getDependencyType() !== dependency_interface_1.DependencyType.DEPENDENCY_TYPE_HSP ||
            (dependency_manager_1.DependencyManager.isLocalDependency(e, this.moduleModelNodePaths) ||
                !!t == !!e.getUseNormalizedOHMUrl())
    }

    getExtendSourceDirsValidateResult() {
        var e;
        let t = "", i = "";
        const o = this.targetService.getTargetData(),
            r = null === (e = o.getTargetOpt().source) || void 0 === e ? void 0 : e.sourceRoots;
        if (!(null == r ? void 0 : r.length)) {
            return { isValid: !0, cause: t, detail: i };
        }
        const s = this.getCauseAndDetail(o, r, t, i);
        return t = s.cause, i = s.detail, { isValid: !(t && i), cause: t, detail: i }
    }

    getCauseAndDetail(e, t, i, o) {
        const r = this.pathInfo.getModuleSrcPath(), s = this.pathInfo.getModuleSrcMainPath().split(path.sep).length, a =
            `targets[${this.moduleModel.getTargetOptions()
                .findIndex((t => t.name === e.getTargetName()))}].source.sourceRoots`, n = new Set;
        let l = i, d = o;
        for (const e of t) {
            if (path.isAbsolute(e)) {
                l = `Invalid value '${e}' in module '${this.moduleModel.getName()}'.`, d =
                    `Make sure the values of '${a}' are relative paths.`;
                break
            }
            let t = path.resolve(this.pathInfo.getModulePath(), e);
            if (!fs_1.default.existsSync(t)) {
                l = `Path '${e}' not found in module '${this.moduleModel.getName()}'.`, d =
                    `Make sure the values of '${a}' are valid paths.`;
                break
            }
            let i = fs_1.default.lstatSync(t);
            if (i.isSymbolicLink()) {
                try {
                    t = fs_1.default.realpathSync(t), i = fs_1.default.lstatSync(t)
                } catch {
                    l = `Path '${e}' not found in module '${this.moduleModel.getName()}'.`, d =
                        `Make sure the values of '${a}' are valid paths.`;
                    break
                }
            }
            if (!i.isDirectory()) {
                l = `Invalid value '${e}' in module '${this.moduleModel.getName()}'.`, d =
                    `Make sure the values of '${a}' are valid directory paths.`;
                break
            }
            if (!file_util_1.FileUtil.isSubDir(r, t) || t.split(path.sep).length !== s) {
                l = `Invalid value '${e}' in module '${this.moduleModel.getName()}'.`, d =
                    `Make sure the values of '${a}' are subdirectories of '${r}'.`;
                break
            }
            if (n.has(t)) {
                l = `Invalid value '${e}' in module '${this.moduleModel.getName()}'.`, d =
                    `Make sure the values of '${a}' are unique.`;
                break
            }
            n.add(t)
        }
        return { cause: l, detail: d }
    }

    checkIntegratedHspHsp() {
        var e, t;
        const i =
            null === (e = this.targetService.getBuildOption().arkOptions) || void 0 === e ? void 0 : e.integratedHsp,
            o = null === (t = this.targetService.getBuildOption().strictMode) || void 0 === t ? void 0 :
            t.useNormalizedOHMUrl;
        i && !(0, task_util_1.limitMinApiVersion)(this.targetData, sdk_const_1.ApiVersion.API_VERSION_11) &&
        _log._buildError("The integratedHsp can only be used in API 12 and later.")
            ._file(`${this.moduleModel.getProfilePath()}`)._printErrorAndExit(), i && !o &&
        _log._buildError("The integratedHsp is available only when useNormalizedOHMUrl is set to true.")
            ._printErrorAndExit(), i && this.service.getModuleModel().isHapModule() &&
        _log.warn(`The integratedHsp does not take effect in the HAP ${this.moduleModel.getName()}.`)
    }

    checkTransformLib() {
        var e, t;
        const i =
            null === (t = null === (e = this.targetService.getBuildOption()) || void 0 === e ? void 0 : e.arkOptions) ||
                void 0 === t ? void 0 : t.transformLib;
        if (i) {
            !inject_util_1.InjectUtil.isInTest() && this.targetService.isSourceCodeHar() &&
            _log.warn("Only the byte code har supports to configure the 'transformLib' field."), path.isAbsolute(i) &&
            _log.errorMessageExit(`Invalid transformLib, its value should be a relative path.,  \n        at File: ${path.resolve(this.pathInfo.getModulePath(),
                "build-profile.json5")}`);
            const e = path.resolve(this.pathInfo.getModulePath(), i);
            fs_1.default.existsSync(e) ? (fs_1.default.statSync(e).isFile() ||
            _log.errorMessageExit(`Invalid transformLib value ${i} is not File,\n         at File: ${path.resolve(this.pathInfo.getModulePath(),
                "build-profile.json5")}`), this.checkTransformLibFileType(e.substring(e.lastIndexOf(".") + 1))) :
            _log.errorMessageExit(`Invalid transformLib value, ${i} is not exist,\n         at File: ${path.resolve(this.pathInfo.getModulePath(),
                "build-profile.json5")}`)
        }
    }

    checkTransformLibFileType(e) {
        (0, hvigor_1.isWindows)() && "dll" !== e &&
        _log.errorMessageExit(`Invalid transformLib value, it requires a .dll file in Windows,  \n        at File: ${path.resolve(this.pathInfo.getModulePath(),
            "build-profile.json5")}`), ((0, hvigor_1.isMac)() || (0, hvigor_1.isLinux)()) && "so" !== e &&
        _log.errorMessageExit(`Invalid file type, it requires a .so file in Mac or Linux, \n        at File: ${path.resolve(this.pathInfo.getModulePath(),
            "build-profile.json5")}`)
    }

    checkResReferenceConfig(e) {
        const t = res_model_loader_1.resModelLoader.getModuleJson(this.targetJsonPath).module[e];
        if (!t) {
            return;
        }
        const i = (0, common_util_1.parsingProfileName)(t);
        if (!i) {
            return;
        }
        const o = this.targetService.getTargetResourceBaseProfilePath(`${i}.json`);
        o && fs_1.default.existsSync(o) ||
        _log._buildError(`Invalid configuration in the '${this.moduleName}' ${common_const_1.CommonConst.MODULE_JSON5}.`)
            ._detail(`The path of '${e}' configuration file does not exist.`)
            ._file(module_option_path_info_1.moduleOptionPathInfo.getModuleOptPath(this.targetJsonPath, e))
            ._printErrorAndExit()
    }

    validateModuleSrcEntry(e, t) {
        const i = t.module.srcEntry || t.module.srcEntrance;
        if (void 0 === i) {
            return;
        }
        const o = this.moduleModel.getSourceSetByTargetName(this.targetData.getTargetName());
        void 0 === t.module.srcEntry &&
        _log.warn(`Field "module.srcEntrance" has been deprecated. Use "module.srcEntry" instead.       \n      at ${o.getModuleTargetRes()
            .getJsonPath()}`);
        const r = path.isAbsolute(i) ? i : path.resolve(o.getSourceSetRoot(), i);
        if (!(file_util_1.FileUtil.fileExists(r) ||
            (0, cangjie_file_util_1.onlyCangjieModule)(this.moduleModel.getProjectDir()) &&
            constants_1.CJ_ABILITY_NAME_REG.test(i))) {
            const t = o;
            e._buildError(`Module-srcEntry '${i}' not found.`)
                ._solution(`Make sure ${i} exists.`)
                ._file(t.getModuleTargetRes().getJsonPath())
                ._errorCode(error_code_map_1.ECM.DECE.SERVICE_LOGIC)
                ._printErrorAndExit()
        }
    }

    checkApi() {
        (this.compileApiVersion < sdk_const_1.ApiVersion.API_VERSION_11 ||
            this.apiType === hap_extra_info_1.ApiType.FA) &&
        _log._buildError(`Invalid configuration of runtimeOnly in '${this.moduleModel.getName()}' ${common_const_1.CommonConst.PROFILE_JSON5}`)
            ._detail(`The field of runtimeOnly for dynamic import only supports the ${sdk_const_1.ApiVersion.API_VERSION_11} or later ${hap_extra_info_1.ApiType.STAGE} mode project.`)
            ._file(this.profilePath)._printErrorAndExit()
    }

    checkDependencies(e) {
        const t = Object.keys(this.getDependencies(this.moduleModel, !1)),
            i = Object.keys(this.getDependencies(this.projectModel, !1));
        if (e.packages && !(0, array_util_1.isSubset)((0, array_util_1.getUnionSet)(t, i), e.packages)) {
            const e = `Invalid dynamic import configurations in current module '${this.moduleModel.getName()}'.`, t =
                `All dynamic import files or relative paths configured for the '${this.moduleModel.getName()}' must exist in the added dependencies in its ${common_const_1.CommonConst.OH_PACKAGE_JSON5}.`;
            _log._buildError(e)._detail(t)._file(this.profilePath)._printErrorAndExit()
        }
    }

    checkAcrossModule(e, t, i) {
        0 !== e.length && (t ?
        _log._buildError(`Invalid dynamic import configuration [${e}] in current module '${this.moduleName}'.`)
            ._detail("The sources configuration of runtimeOnly in module is not allowed to configure across modules when strictMode-noExternalImportByPath is true.")
            ._file(i)._printErrorAndExit() :
        _log.warn(`Invalid dynamic import configuration [${e}] in current module '${this.moduleName}'. \n   Detail: The sources configuration of runtimeOnly in module is not allowed to configure across modules.\n   at :${i}`))
    }

    checkSuffixFile(e, t) {
        0 !== e.length &&
        _log._buildError(`Invalid file [${e}] found in the module '${this.moduleName}' dynamic import files.`)
            ._detail("The dynamic import file must end with ts or ets.")._file(t)._printErrorAndExit()
    }

    checkOutsideModuleFile(e, t) {
        0 !== e.length &&
        _log._buildError(`Invalid dynamic import configuration [${[...new Set(e)]}] in current module '${this.moduleName}'.`)
            ._detail("The relative path of the file which is not in the current module or other modules in the project cannot be configured for dynamic import.")
            ._file(t)._printErrorAndExit()
    }

    checkExistFilePath(e, t) {
        0 !== e.length &&
        _log._buildError(`Unable to find the file or directory for '${this.moduleName}' using the relative path [${e}].`)
            ._detail(`Verify the path under 'runtimeOnly' in the module '${this.moduleName}' ${common_const_1.CommonConst.PROFILE_JSON5}.`)
            ._file(t)._printErrorAndExit()
    }

    checkAppStartupConfig() {
        const e = this.targetService.getAppStartupPath();
        if (!e || !fs_1.default.existsSync(e)) {
            return;
        }
        const t = (0, json_util_1.getJson5Obj)(e);
        this.checkStartupTaskName(t.startupTasks), t.startupTasks.forEach((t => {
            this.checkStartupPath(e, t.srcEntry)
        })), this.checkStartupPath(e, t.configEntry)
    }

    checkStartupTaskName(e) {
        if (!e || e.length <= 1) {
            return;
        }
        const t = e.map((e => e.name));
        new Set(t).size !== t.length &&
        _log._buildError(`Duplicate object name of startupTask in the '${this.moduleName}' app startup configuration file.`)
            ._detail("The object name of startupTask in the app startup configuration file must be unique.")
            ._file(this.targetService.getAppStartupPath())._printErrorAndExit()
    }

    checkStartupPath(e, t) {
        const i = `Invalid app startup configuration '${t}' in the module '${this.moduleName}'.`, o =
            path.resolve(this.moduleModel.getModule().getNodeDir(), build_directory_const_1.BuildDirConst.SRC,
                build_directory_const_1.BuildDirConst.MAIN, t);
        common_const_1.ValidateRegExp.STARTUP_TASK_SRC_ENTRY_REG_EXP.test(path.extname(o)) || _log._buildError(i)
            ._detail("The suffix of the code file specified by the field 'srcEntry' or 'configEntry' must be ets,ts or js.")
            ._file(e)._printErrorAndExit(), fs_1.default.existsSync(o) ||
        _log._buildError(i)._detail("The code file specified by the field 'srcEntry' or 'configEntry' must exist.")
            ._file(e)._printErrorAndExit()
    }

    checkAllSrcEntry() {
        const e = new Map, t = res_model_loader_1.resModelLoader.getModuleJson(this.targetJsonPath);
        t.module.srcEntry && e.set(this.MODULE_SRC_ENTRY, [t.module.srcEntry]);
        const i = t.module.abilities, o = [];
        if (null == i ? void 0 : i.length) {
            for (const e of i) {
                e.srcEntry && o.push(e.srcEntry);
            }
            e.set(this.MODULE_ABILITIES_SRC_ENTRY, o)
        }
        const r = t.module.extensionAbilities, s = [];
        if (r) {
            for (const e of r) {
                e.srcEntry && s.push(e.srcEntry);
            }
            e.set(this.MODULE_EXTENSION_ABILITIES_SRC_ENTRY, s)
        }
        const a = [];
        if (fs_1.default.existsSync(this.insightIntentJsonPath)) {
            const t = (0, json_util_1.getJson5Obj)(this.insightIntentJsonPath);
            for (const e of t.insightIntents) {
                e.srcEntry && a.push(e.srcEntry);
            }
            e.set(this.INSIGHT_INTENT_SRC_ENTRY, a)
        }
        this.checkSrcEntry(e)
    }

    checkSrcEntry(e) {
        e.forEach(((e, t) => {
            if (!(null == e ? void 0 : e.length)) {
                return;
            }
            const i = (0, cangjie_file_util_1.onlyCangjieModule)(this.moduleModel.getProjectDir());
            null == e || e.forEach((e => {
                common_const_1.ValidateRegExp.RELATIVE_PATH_REG_EXP.test(e) ||
                    i && constants_1.CJ_ABILITY_NAME_REG.test(e) ||
                _log._buildError(`Invalid configuration of '${t}' field.`)
                    ._detail(i ? "The srcEntry format should be packageName.AbilityClassName." :
                        "Relative file path(like ./**) is required for srcEntry.")
                    ._file(t === this.INSIGHT_INTENT_SRC_ENTRY ? this.insightIntentJsonPath : this.targetJsonPath)
                    ._printErrorAndExit()
            }))
        }))
    }

    getDeclareInputs(e) {
        var t, i, o, r, s, a, n, l;
        e.set(common_const_1.CommonConst.USE_NORMALIZED_OHM_URL, !!(null ===
            (i = null === (t = this.targetService.getBuildOption()) || void 0 === t ? void 0 : t.strictMode) ||
            void 0 === i ? void 0 : i.useNormalizedOHMUrl)), e.set(build_directory_const_1.BuildDirConst.INTEGRATED_HSP,
            !!(null === (o = this.targetService.getBuildOption().arkOptions) || void 0 === o ? void 0 :
            o.integratedHsp)), e.set("sourceRoots",
            this.extendSourceValidateResult.isValid), e.set(build_directory_const_1.BuildDirConst.TRANSFORM_LIB,
            null !== (a = null ===
                (s = null === (r = this.targetService.getBuildOption()) || void 0 === r ? void 0 : r.arkOptions) ||
                void 0 === s ? void 0 : s.transformLib) && void 0 !== a ? a : ""), e.set("byteCodeHar", !!(null ===
            (l = null === (n = this.targetService.getBuildOption()) || void 0 === n ? void 0 : n.arkOptions) ||
            void 0 === l ? void 0 :
        l.byteCodeHar)), this.addConfigurationToInput(e), fs_1.default.existsSync(this.moduleModel.getMockConfigPath()) &&
        e.set("mockConfigSources", (0, mock_config_utils_1.getMockConfigSources)(this.moduleModel.getMockConfigPath(),
            this.moduleModel.getProjectDir()).join(","))
    }

    checkBundledDependencies() {
        var e, t, i, o;
        if (!this.targetService.isBundledDependencies()) {
            return;
        }
        const r =
            null === (t = null === (e = this.targetService.getBuildOption()) || void 0 === e ? void 0 : e.strictMode) ||
                void 0 === t ? void 0 : t.useNormalizedOHMUrl;
        // this.targetService.getByteCodeHar(r,
        //     null === (o = null === (i = this.targetService.getBuildOption()) || void 0 === i ? void 0 : i.arkOptions) ||
        //         void 0 === o ? void 0 : o.byteCodeHar) ||
        // _log._buildError("Only the byte code har supports to configure the bundledDependencies.")
        //     ._detail("The 'buildOption.strictMode' must have required property 'useNormalizedOHMUrl' and its value must be true in project-level build-profile.json5, and 'buildOption.arkOptions.byteCodeHar' can not be false in module-level build-profile.json5.")
        //     ._printErrorAndExit()
    }
}

exports.CangjiePreBuild = CangjiePreBuild;